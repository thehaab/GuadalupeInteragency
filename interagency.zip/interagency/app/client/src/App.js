// client/src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import Home from './components/Home/home';
import Register from './components/Auth/Register';
import Login from './components/Auth/Login';
import Dashboard from './components/Dashboard/Dashboard';
import Profile from './components/Profile/Profile';
import MyNavbar from './components/navbar/navbar';
import { isAuthenticated } from './utils/auth';
import { PrivateRoute } from './components/Auth/PrivateRoute';

function App() {
  return (
    <Router>
      <div className="App">
        <MyNavbar />
        
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          
          {/* Protected routes */}
          <Route 
            path="/dashboard" 
            element={
              <PrivateRoute>
                <Dashboard />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/profile" 
            element={
              <PrivateRoute>
                <Profile />
              </PrivateRoute>
            } 
          />
          
          {/* Add more routes as needed */}
        </Routes>
        
        <footer>
          <p>&copy; 2024 Connect Guadalupe. All rights reserved.</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;