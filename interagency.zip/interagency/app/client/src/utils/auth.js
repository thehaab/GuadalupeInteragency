// client/src/utils/auth.js
import jwt_decode from 'jwt-decode';

export const isAuthenticated = () => {
  const token = localStorage.getItem('token');
  if (!token) return false;

  try {
    const decoded = jwt_decode(token);
    const currentTime = Date.now() / 1000; // to get in milliseconds
    
    if (decoded.exp < currentTime) {
      // Token has expired
      localStorage.removeItem('token');
      return false;
    }
    
    return true;
  } catch (error) {
    console.error("Error decoding token:", error);
    return false;
  }
};

export const logout = () => {
  localStorage.removeItem('token');
  // You might want to redirect to login page or refresh the app state here
};