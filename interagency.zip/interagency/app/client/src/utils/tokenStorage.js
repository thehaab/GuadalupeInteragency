// client/src/utils/tokenStorage.js

let inMemoryToken = null;
let refreshToken = null;

export const setTokens = (accessToken, newRefreshToken) => {
  inMemoryToken = accessToken;
  refreshToken = newRefreshToken;
};

export const getAccessToken = () => inMemoryToken;

export const getRefreshToken = () => refreshToken;

export const clearTokens = () => {
  inMemoryToken = null;
  refreshToken = null;
};