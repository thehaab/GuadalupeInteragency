// constants.js

// Server configuration
const PORT = process.env.PORT || 5000;

// Database configuration
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/your_database_name';

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';
const JWT_EXPIRE = '24h';

// API endpoints
const API_PREFIX = '/api/v1';

// CORS configuration
const CORS_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:3000';

// Other constants
const ITEMS_PER_PAGE = 10;

module.exports = {
  PORT,
  MONGODB_URI,
  JWT_SECRET,
  JWT_EXPIRE,
  API_PREFIX,
  CORS_ORIGIN,
  ITEMS_PER_PAGE
};