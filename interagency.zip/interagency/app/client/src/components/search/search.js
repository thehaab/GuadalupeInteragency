import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { FaSearch } from 'react-icons/fa';

const Search = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const performSearch = useCallback(async () => {
    setIsLoading(true);
    try {
      // Replace this with your actual API call
      const response = await fetch(`/api/search?term=${searchTerm}`);
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Error performing search:', error);
      setSearchResults([]);
    } finally {
      setIsLoading(false);
    }
  }, [searchTerm]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      if (searchTerm) {
        performSearch();
      } else {
        setSearchResults([]);
      }
    }, 300); // Debounce by 300ms

    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm, performSearch]);

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const renderResultItem = (item) => {
    switch (item.type) {
      case 'resource':
        return (
          <Link to={`/resources/${item.id}`} className="search-result-item">
            <h3>{item.name}</h3>
            <p>{item.description}</p>
          </Link>
        );
      case 'organization':
        return (
          <Link to={`/organizations/${item.id}`} className="search-result-item">
            <h3>{item.name}</h3>
            <p>{item.mission}</p>
          </Link>
        );
      case 'event':
        return (
          <Link to={`/events/${item.id}`} className="search-result-item">
            <h3>{item.name}</h3>
            <p>{item.date} - {item.location}</p>
          </Link>
        );
      default:
        return null;
    }
  };

  return (
    <div className="search-component">
      <FaSearch size={30} />
      <input
        type="text"
        placeholder="Search resources, organizations, and events..."
        value={searchTerm}
        onChange={handleInputChange}
        className="search-input"
      />
      {isLoading && <p>Loading...</p>}
      <div className="search-results">
        {searchResults.map((item) => (
          <div key={`${item.type}-${item.id}`}>
            {renderResultItem(item)}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Search;
