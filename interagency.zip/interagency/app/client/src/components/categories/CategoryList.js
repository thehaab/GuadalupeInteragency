// components/CategoryList.js
import React from 'react';
import { Link } from 'react-router-dom';
import useCategories from '../hooks/useCategories';
import './CategoryList.css'; // You'll need to create this CSS file

const CategoryList = () => {
  const { categories, loading, error } = useCategories();

  if (loading) return <div>Loading categories...</div>;
  if (error) return <div>Error: {error}</div>;

  return (
    <div className="category-list">
      <h2>Resource Categories</h2>
      {categories.length === 0 ? (
        <p>No categories found.</p>
      ) : (
        <ul>
          {categories.map((category) => (
            <li key={category.id}>
              <Link to={`/resources/${category.id}`}>
                <div className="category-item">
                  <img src={category.icon} alt={category.name} />
                  <span>{category.name}</span>
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default CategoryList;