import React from 'react';
import { Card, CardContent, Typography, Button, Chip, Box } from '@mui/material';
import { LocationOn, Phone, Language } from '@mui/icons-material';

const ResourceCard = ({ organization }) => {
  return (
    <Card sx={{ maxWidth: 345, m: 2 }}>
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {organization.name}
        </Typography>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          {organization.description}
        </Typography>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <LocationOn fontSize="small" sx={{ mr: 1 }} />
          <Typography variant="body2">{organization.address}</Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Phone fontSize="small" sx={{ mr: 1 }} />
          <Typography variant="body2">{organization.phone}</Typography>
        </Box>
        
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Language fontSize="small" sx={{ mr: 1 }} />
          <Typography variant="body2">{organization.website}</Typography>
        </Box>
        
        <Typography variant="subtitle2" sx={{ mb: 1 }}>Services:</Typography>
        <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
          {organization.services.map((service, index) => (
            <Chip key={index} label={service} size="small" />
          ))}
        </Box>
        
        <Button variant="contained" fullWidth>
          Learn More
        </Button>
      </CardContent>
    </Card>
  );
};

export default ResourceCard;