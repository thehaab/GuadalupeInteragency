/* // AccessPanel.js
import { useAccessibility } from './AccessibilityContext.js';

function AccessPanel() {
  const { highContrast, setHighContrast, largeText, setLargeText, darkMode, setDarkMode, espanol, setEspanol } = useAccessibility();

  return (
    <div className="accessibility-panel">
      <button onClick={() => setHighContrast(!highContrast)}>
        {highContrast ? 'Disable' : 'Enable'} High Contrast
      </button>
      <button onClick={() => setLargeText(!largeText)}>
        {largeText ? 'Disable' : 'Enable'} Large Text
      </button>
      <button onClick={() => setDarkMode(!darkMode)}>
        {darkMode ? 'Disable' : 'Enable'} Dark Mode
      </button>
      <button onClick={() => setEspanol(!espanol)}>
        {espanol ? 'English' : 'Español'}
      </button>
    </div>
  );
}

export default AccessPanel; */