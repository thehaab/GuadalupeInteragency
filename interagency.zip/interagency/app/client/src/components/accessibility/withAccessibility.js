import React from 'react';
import { useAccessibility } from './AccessibilityContext.js';

export const withAccessibility = (WrappedComponent) => {
  return (props) => {
    let accessibilityContext;
    try {
      accessibilityContext = useAccessibility();
    } catch (error) {
      console.error('Error using AccessibilityContext:', error);
      return null; // or some fallback UI
    }

    if (!accessibilityContext) {
      console.error('AccessibilityContext is undefined');
      return null; // or some fallback UI
    }

    const { highContrast, largeText, darkMode, espanol } = accessibilityContext;
    
    const accessibilityClass = `
      ${highContrast ? 'high-contrast' : ''}
      ${largeText ? 'large-text' : ''}
      ${darkMode ? 'dark-mode' : ''}
      ${espanol ? 'espanol' : ''}
    `.trim();

    return (
      <WrappedComponent 
        {...props} 
        className={`${props.className || ''} ${accessibilityClass}`.trim()}
      />
    );
  };
}


/* wrap the component with the accessibility context as follows:

// MyComponent.js
import { withAccessibility } from './withAccessibility';

function MyComponent({ className }) {
  return <div className={className}>Content</div>;
}

export default withAccessibility(MyComponent);

*/