/* // AccessibilityContext.js
import React, { createContext, useState, useContext } from 'react';

console.log('AccessibilityContext is being executed');

const AccessibilityContext = createContext();

export const AccessibilityProvider = ({ children }) => {
  console.log('AccessibilityProvider is rendering');
  // ... rest of your code
};

export const useAccessibility = () => {
  const context = useContext(AccessibilityContext);
  if (context === undefined) {
    throw new Error('useAccessibility must be used within an AccessibilityProvider');
  }
  return context;
}; */