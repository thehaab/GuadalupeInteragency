import React from 'react';
// import { Link } from 'react-router-dom';
import './Home.css'; // You'll need to create this CSS file
import Hero from '../hero/Hero.js';
import Search from '../search/search.js';
import EventsCalendar from '../events/EventsCalendar.js';

function Home() {
  return (
    <div className="home">
      <Search />
      <Hero />
      <h2>Upcoming Events</h2>
      <EventsCalendar className='eventsCalendarLabel'/>
    </div>
  );
}

export default Home;
