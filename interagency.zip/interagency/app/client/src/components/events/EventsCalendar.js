import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import './EventsCalendar.css';

// Set up the localizer for react-big-calendar
const localizer = momentLocalizer(moment);

// Custom Popup Component
const CustomPopup = ({ events, onSelectEvent, onClose }) => (
  <div className="custom-popup">
    <button className="custom-popup-close" onClick={onClose}>×</button>
    <h3 className="custom-popup-header">{events[0].start.toDateString()}</h3>
    {events.map((event, index) => (
      <div key={index} className="custom-popup-event" onClick={() => onSelectEvent(event)}>
        <span className="custom-popup-event-time">
          {moment(event.start).format('HH:mm')} - {moment(event.end).format('HH:mm')}
        </span>
        <span className="custom-popup-event-title">{event.title}</span>
      </div>
    ))}
  </div>
);

// Event Modal Component
const EventModal = ({ event, onClose }) => (
  <div className="event-modal-overlay" onClick={onClose}>
    <div className="event-modal-content" onClick={e => e.stopPropagation()}>
      <button className="event-modal-close" onClick={onClose}>×</button>
      <h2>{event.title}</h2>
      <p><strong>Start:</strong> {event.start.toLocaleString()}</p>
      <p><strong>End:</strong> {event.end.toLocaleString()}</p>
      {event.description && <p><strong>Description:</strong> {event.description}</p>}
      {event.location && <p><strong>Location:</strong> {event.location}</p>}
    </div>
  </div>
);

function EventsCalendar() {
  // Sample events data - replace this with your actual events data
  const [events, setEvents] = useState([
    {
      id: 1,
      title: 'Community Meeting',
      start: new Date(2024, 9, 15, 10, 0), // October 15, 2024, 10:00 AM
      end: new Date(2024, 9, 15, 12, 0),   // October 15, 2024, 12:00 PM
    },
    {
      id: 2,
      title: 'Food Drive',
      start: new Date(2024, 9, 20, 9, 0),  // October 20, 2024, 9:00 AM
      end: new Date(2024, 9, 20, 14, 0),   // October 20, 2024, 2:00 PM
    },
    // Add more events as needed
  ]);

  const [selectedEvent, setSelectedEvent] = useState(null);

  const handleSelectEvent = (event) => {
    setSelectedEvent(event);
  };

  const closeModal = () => {
    setSelectedEvent(null);
  };

  // Define the components object
  const components = {
    popup: CustomPopup
  };

  return (
    <div className='eventsCalendar custom-calendar' style={{ height: '500px' }}>
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        style={{
          height: '100%', 
          backgroundColor: 'valencia' 
        }}
        components={components}
        onSelectEvent={handleSelectEvent}
        popup
          />
      {selectedEvent &&
        <EventModal
          event={selectedEvent}
          onClose={closeModal}
        />
      }
    </div>
  );
}

export default EventsCalendar;