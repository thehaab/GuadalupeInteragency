import React from 'react';

const EventModal = ({ event, onClose }) => (
  <div className="event-modal-overlay" onClick={onClose}>
    <div className="event-modal-content" onClick={e => e.stopPropagation()}>
      <button className="event-modal-close" onClick={onClose}>×</button>
      <h2>{event.title}</h2>
      <p><strong>Start:</strong> {event.start.toLocaleString()}</p>
      <p><strong>End:</strong> {event.end.toLocaleString()}</p>
      {event.description && <p><strong>Description:</strong> {event.description}</p>}
      {event.location && <p><strong>Location:</strong> {event.location}</p>}
    </div>
  </div>
);
