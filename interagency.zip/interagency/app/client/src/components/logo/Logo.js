import React from 'react';

const Logo = ({ width , height }) => {
  return (<>
    <svg className='logo' width="100%" height="100%" viewBox="0 0 37.698 18.82">
      <text
        x="3.83"
        y="10.221"
        style={{
          fontStyle: "normal",
          fontVariant: "normal",
          fontWeight: 400,
          fontStretch: "normal",
          fontSize: "10.263px",
          fontFamily: "Helvetica",
          letterSpacing: "-.030789px",
          fill: "#333",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "#75ff8f",
          strokeWidth: "1.45458e-08",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeDasharray: "none",
          strokeOpacity: 0.998867,
          paintOrder: "stroke markers fill"
        }}
        transform="skewX(-.054)scale(1.00743 .99262)"
      >
        <tspan
          x="3.83"
          y="10.221"
          style={{
            fontStyle: "normal",
            fontVariant: "normal",
            fontWeight: 400,
            fontStretch: "normal",
            fontFamily: "Inter",
            fill: "#333",
            fillOpacity: 1,
            strokeWidth: "1.45458e-08",
            strokeDasharray: "none"
          }}
        >
          C
        </tspan>
      </text>
      <text
        x="3.93"
        y="15.545"
        style={{
          fontStyle: "normal",
          fontVariant: "normal",
          fontWeight: 400,
          fontStretch: "normal",
          fontSize: "10.3043px",
          fontFamily: "Helvetica",
          letterSpacing: "-.030913px",
          fill: "#6e9382",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "#75ff8f",
          strokeWidth: 0,
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeDasharray: "none",
          strokeOpacity: 0.998867,
          paintOrder: "stroke markers fill"
        }}
      >
        <tspan
          x="3.93"
          y="15.545"
          style={{
            fontStyle: "normal",
            fontVariant: "normal",
            fontWeight: 400,
            fontStretch: "normal",
            fontFamily: "Inter",
            fill: "#6e9382",
            fillOpacity: 1,
            strokeWidth: 0,
            strokeDasharray: "none"
          }}
        >
          G
        </tspan>
      </text>
      <text
        x="11.956"
        y="10.187"
        style={{
          fontStyle: "normal",
          fontVariant: "normal",
          fontWeight: 400,
          fontStretch: "normal",
          fontSize: "5.03031px",
          fontFamily: "Inter",
          letterSpacing: "-.015091px",
          fill: "#333",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "#75ff8f",
          strokeWidth: "5.65909e-09",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeDasharray: "none",
          strokeOpacity: 0.998867,
          paintOrder: "stroke markers fill"
        }}
      >
        <tspan
          x="11.956"
          y="10.187"
          style={{
            fill: "#333",
            fillOpacity: 1,
            strokeWidth: "5.65909e-09"
          }}
        >
          onnect
        </tspan>
      </text>
      <text
        x="11.857"
        y="14.04"
        style={{
          fontStyle: "normal",
          fontVariant: "normal",
          fontWeight: 400,
          fontStretch: "normal",
          fontSize: "4.90796px",
          fontFamily: "Inter",
          letterSpacing: "-.0147239px",
          fill: "#6e9382",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "#75ff8f",
          strokeWidth: "5.52143e-09",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeDasharray: "none",
          strokeOpacity: 0.998867,
          paintOrder: "stroke markers fill"
        }}
      >
        <tspan
          x="11.857"
          y="14.04"
          style={{
            fill: "#6e9382",
            fillOpacity: 1,
            strokeWidth: "5.52143e-09"
          }}
        >
          uadalupe
        </tspan>
      </text>
      <path
        d="m7.804 10.245-.903-.1c.194-.16.972-.84 1.554-1.392.223-.195.677-.998.728-1.313h2.07a2.7 2.7 0 0 1-.269.965q-.226.492-.657.91a3.2 3.2 0 0 1-1.05.677c-.415.169-.92.253-1.473.253"
        style={{
          fontSize: "10.263px",
          fontFamily: "Inter",
          letterSpacing: "-.030789px",
          fill: "#333",
          fillOpacity: 1,
          fillRule: "evenodd",
          stroke: "#75ff8f",
          strokeWidth: "1.45458e-08",
          strokeLinecap: "round",
          strokeLinejoin: "round",
          strokeOpacity: 0.998867,
          paintOrder: "stroke markers fill"
        }}
      />
    </svg> </>
  );
};

export default Logo;