import React from 'react';
import './hero.css';
import { FaHeartbeat, FaGraduationCap, FaHome, FaUtensils, FaBriefcase, FaGavel, FaBrain, FaWheelchair, FaUserFriends, FaChild, FaDove, /* FaInfinity */ } from 'react-icons/fa';

function Hero() {
  return (
    <div className="hero">
      <div className="hero-content">
        <h1>Empowering Our Community</h1>
        <p>Explore our diverse range of services and resources</p>
        <div className="icon-list">
          <a href='#health' className="icon-item">
            <FaHeartbeat size={50} />
            <h3>Health</h3>
          </a>
          <a href='#education' className="icon-item">
            <FaGraduationCap size={50} />
            <h3>Education</h3>
          </a>
          <a href='#housing' className="icon-item">
            <FaHome size={50} />
            <h3>Housing</h3>
          </a>
          <a href='#food' className="icon-item">
            <FaUtensils size={50} />
            <h3>Food</h3>
          </a>
          <a href='#employment' className="icon-item">
            <FaBriefcase size={50} />
            <h3>Employment</h3>
          </a>
          <a href='#legal' className="icon-item">
            <FaGavel size={50} />
            <h3>Legal</h3>
          </a>
          <a href='#mental-health' className="icon-item">
            <FaBrain size={50} />
            <h3>Mental Health</h3>
          </a>
          <a href='#disability' className="icon-item">
            <FaWheelchair size={50} />
            <h3>Disability</h3>
          </a>
          <a href='#senior-care' className="icon-item">
            <FaUserFriends size={50} />
            <h3>Senior Care</h3>
          </a>
          <a href='#youth-services' className="icon-item">
            <FaChild size={50} />
            <h3>Youth Services</h3>
          </a>
          <a href='#faith-spiritual-resources' className="icon-item">
            <FaDove size={50} />{/* <FaInfinity size={50} /> */}
          <h3>Faith/Spiritual</h3> 
          </a>
        </div>
      </div>
    </div>
  );
}

export default Hero;