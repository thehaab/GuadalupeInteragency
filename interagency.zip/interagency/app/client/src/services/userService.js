// client/src/services/userService.js
import axiosInstance from '../utils/axiosConfig';

const API_URL = 'http://localhost:5000/api/users/';

export const getUserProfile = async () => {
  try {
    const response = await axiosInstance.get(API_URL + 'profile');
    return response.data;
  } catch (error) {
    throw error;
  }
};