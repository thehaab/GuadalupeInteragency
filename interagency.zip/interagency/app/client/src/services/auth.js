// client/src/services/authService.js

import axiosInstance from '../utils/axiosConfig';
import { setTokens, clearTokens } from '../utils/tokenManager';

export const login = async (email, password) => {
  try {
    const response = await axiosInstance.post('/auth/login', { email, password });
    const { accessToken, refreshToken } = response.data;
    setTokens(accessToken, refreshToken);
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const logout = () => {
  clearTokens();
  // Additional logout logic (e.g., redirecting to login page)
  window.location.href = '/';
};